export default class CommentModel {
    constructor(name, date, content, type) {
        this.name = name
        this.date = date
        this.content = content
        this.type = type
    }
}